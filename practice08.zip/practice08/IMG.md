# 画像データ

## Pixabayの画像

* [Pixabay](https://pixabay.com/)
* [Pixabay License](https://pixabay.com/service/license/)

### hero01.jpg
https://pixabay.com/images/id-1680803

### hero02.jpg
https://pixabay.com/images/id-2601876

### natural01.jpg
https://pixabay.com/images/id-1836070

### natural02.jpg
https://pixabay.com/images/id-5669680

### comfort01.jpg
https://pixabay.com/images/id-4246371

### comfort02.jpg
https://pixabay.com/images/id-2559842

### list01.jpg
https://pixabay.com/images/id-1680787

### list02.jpg
https://pixabay.com/images/id-2935773

### list03.jpg
https://pixabay.com/images/id-1577438



---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データ以外のライセンスに準拠するものとします。

### accent.svg
### bars-left.svg
### bars-right.svg
### logo.svg
### logo-box.svg
### more.svg
