# 画像データ

## Pixabayの画像

* [Pixabay](https://pixabay.com/)
* [Pixabay License](https://pixabay.com/service/license/)

### camp-fire.jpg
https://pixabay.com/images/id-279748

### camp-food.jpg
https://pixabay.com/images/id-5481465

### camp-sky.jpg
https://pixabay.com/images/id-4279127

### camp-table.jpg
https://pixabay.com/images/id-4556147

### fire.jpg
https://pixabay.com/images/id-3312

### tent.jpg
https://pixabay.com/images/id-548022

### tent-green.jpg
https://pixabay.com/images/id-2587926

### tent-orange.jpg
https://pixabay.com/images/id-2339491


---

## SNSのロゴ画像

* 詳しくは各社のページを参照してください。

### logo-twitter.svg
https://about.twitter.com/ja/company/brand-resources.html

### logo-facebook.svg
https://ja.facebookbrand.com/facebookapp/assets/%E3%80%8Cf%E3%80%8D%E3%83%AD%E3%82%B4/

### logo-instagram.svg
https://en.instagram-brand.com/assets/icons



---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データ以外のライセンスに準拠するものとします。

### chat.svg
