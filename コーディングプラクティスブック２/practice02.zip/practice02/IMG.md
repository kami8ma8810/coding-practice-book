# 画像データ

## Pixabayの画像

* [Pixabay](https://pixabay.com/)

### cafe.jpg
https://pixabay.com/photos/3189979

### beans.jpg
https://pixabay.com/photos/917613

### espresso.jpg
https://pixabay.com/photos/206142

### plate.jpg
https://pixabay.com/photos/2372076

### cake.jpg
https://pixabay.com/photos/643216

### sandwich.jpg
https://pixabay.com/photos/4077817

### shop.jpg
https://pixabay.com/photos/4472312

### texture.jpg
https://pixabay.com/photos/1099399


---

## SNSのロゴ画像

* 詳しくは各社のページを参照してください。

### logo-twitter.svg
https://about.twitter.com/ja/company/brand-resources.html

### logo-facebook.svg
https://ja.facebookbrand.com/facebookapp/assets/%E3%80%8Cf%E3%80%8D%E3%83%AD%E3%82%B4/

### logo-instagram.svg
https://en.instagram-brand.com/assets/icons


---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データとPolyfill以外のライセンスに準拠するものとします。


### yamacafe-w.svg
### yamacafe.svg
### catch.svg
### arrow.svg
### mark.svg
### cafe.svg
### plate.svg
### sweet.svg
### favicon.svg
### favion.png
### edge.png

