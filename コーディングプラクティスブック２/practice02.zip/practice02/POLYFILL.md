# IE11対応用のPolyfill


## css-variables-polyfill
https://github.com/aaronbarker/css-variables-polyfill

Copyright (c) 2018 Aaron Barker
Released under the MIT license
https://github.com/aaronbarker/css-variables-polyfill/blob/master/LICENSE


## object-fit-images
https://github.com/fregante/object-fit-images

Copyright (c) Federico Brigante <opensource@bfred.it> (bfred.it)
Released under the MIT license
https://github.com/fregante/object-fit-images/blob/master/license

