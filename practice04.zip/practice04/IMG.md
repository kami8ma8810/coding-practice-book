# 画像データ

## Pixabayの画像

* [Pixabay](https://pixabay.com/)
* [Pixabay License](https://pixabay.com/service/license/)

### business.png
https://pixabay.com/images/id-2579306

### idea.png
https://pixabay.com/images/id-2579308

### secure.png
https://pixabay.com/images/id-2579315

### plan.jpg
https://pixabay.com/images/id-1474454

### wall.jpg
https://pixabay.com/images/id-4621828

### workspace.jpg
https://pixabay.com/images/id-4400306

### workspace-front.jpg
https://pixabay.com/images/id-4400307


---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データとPolyfill以外のライセンスに準拠するものとします。

### mark.svg
