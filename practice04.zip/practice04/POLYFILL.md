# IE11対応用のPolyfill


## object-fit-images
https://github.com/fregante/object-fit-images

Copyright (c) Federico Brigante <opensource@bfred.it> (bfred.it)
Released under the MIT license
https://github.com/fregante/object-fit-images/blob/master/license

