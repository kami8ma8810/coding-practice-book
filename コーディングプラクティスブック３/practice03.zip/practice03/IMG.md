# 画像データ

## Pixabayの画像

* [Pixabay](https://pixabay.com/)

### candy.jpg / candy-dark.jpg
https://pixabay.com/images/id-1952995

### candy01.jpg / candy01-dark.jpg
https://pixabay.com/images/id-1307565

### candy02.jpg / candy02-dark.jpg
https://pixabay.com/images/id-4090697

### candy03.jpg / candy03-dark.jpg
https://pixabay.com/images/id-1952997

### candy04.jpg / candy04-dark.jpg
https://pixabay.com/images/id-2201219

### candy05.jpg / candy05-dark.jpg
https://pixabay.com/images/id-602441

### candy06.jpg / candy06-dark.jpg
https://pixabay.com/images/id-50738

### candy.svg / border.svg / deco.svg
https://pixabay.com/images/id-1814111


---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データとPolyfill以外のライセンスに準拠するものとします。

### colorful.svg
### colorful-yoko.svg
### check.png
### favicon.png
### candy.psd
### candy01-06.psd


